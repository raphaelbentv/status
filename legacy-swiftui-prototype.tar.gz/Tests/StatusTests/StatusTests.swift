import XCTest
@testable import Status

final class StatusTests: XCTestCase {
    func testCompactTokenFormatting() {
        XCTAssertTrue(Int64(1_500_000).compactTokens.contains("1,5"))
        XCTAssertTrue(Int64(12_000).compactTokens.contains("12"))
    }

    func testPreviewDataIsConsistent() {
        let usage = ProviderUsage.preview(.openAI)
        XCTAssertTrue(usage.isPreview)
        XCTAssertEqual(usage.totalTokens, usage.daily.reduce(0) { $0 + $1.totalTokens })
        XCTAssertEqual(usage.costUSD, usage.daily.reduce(0) { $0 + $1.costUSD }, accuracy: 0.0001)
    }
}
