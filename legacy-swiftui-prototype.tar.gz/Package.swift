// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "Status",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "Status", targets: ["Status"])
    ],
    targets: [
        .executableTarget(
            name: "Status",
            linkerSettings: [
                .linkedFramework("AppKit"),
                .linkedFramework("Security")
            ]
        ),
        .testTarget(
            name: "StatusTests",
            dependencies: ["Status"]
        )
    ]
)
