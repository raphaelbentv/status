import Foundation

@MainActor
final class AppStore: ObservableObject {
    static let openAIAccount = "openai-admin-key"
    static let anthropicAccount = "anthropic-admin-key"

    @Published var openAIUsage: ProviderUsage
    @Published var anthropicUsage: ProviderUsage
    @Published var isRefreshing = false
    @Published var errors: [ProviderID: String] = [:]
    @Published var lastRefresh: Date?

    init() {
        UserDefaults.standard.register(defaults: [
            "openAITokenBudget": 10_000_000,
            "anthropicTokenBudget": 10_000_000,
            "openAICostBudget": 50.0,
            "anthropicCostBudget": 50.0,
            "refreshIntervalMinutes": 30
        ])

        if let cached = Self.loadCache() {
            openAIUsage = cached.openAI
            anthropicUsage = cached.anthropic
            lastRefresh = cached.savedAt
        } else {
            openAIUsage = .preview(.openAI)
            anthropicUsage = .preview(.anthropic)
        }
    }

    var providers: [ProviderUsage] { [openAIUsage, anthropicUsage] }
    var totalTokens: Int64 { providers.reduce(0) { $0 + $1.totalTokens } }
    var totalCost: Double { providers.reduce(0) { $0 + $1.costUSD } }
    var isPreview: Bool { providers.allSatisfy(\.isPreview) }

    func usage(for provider: ProviderID) -> ProviderUsage {
        provider == .openAI ? openAIUsage : anthropicUsage
    }

    func tokenBudget(for provider: ProviderID) -> Int64 {
        let key = provider == .openAI ? "openAITokenBudget" : "anthropicTokenBudget"
        return Int64(UserDefaults.standard.integer(forKey: key))
    }

    func costBudget(for provider: ProviderID) -> Double {
        let key = provider == .openAI ? "openAICostBudget" : "anthropicCostBudget"
        return UserDefaults.standard.double(forKey: key)
    }

    func isConfigured(_ provider: ProviderID) -> Bool {
        let account = provider == .openAI ? Self.openAIAccount : Self.anthropicAccount
        return !(KeychainStore.read(account) ?? "").isEmpty
    }

    func refresh() async {
        guard !isRefreshing else { return }
        let openAIKey = KeychainStore.read(Self.openAIAccount) ?? ""
        let anthropicKey = KeychainStore.read(Self.anthropicAccount) ?? ""
        guard !openAIKey.isEmpty || !anthropicKey.isEmpty else { return }

        isRefreshing = true
        errors.removeAll()
        defer { isRefreshing = false }

        async let openAIResult = fetchOpenAI(key: openAIKey)
        async let anthropicResult = fetchAnthropic(key: anthropicKey)
        let (openAI, anthropic) = await (openAIResult, anthropicResult)

        if case .success(let usage) = openAI { openAIUsage = usage }
        if case .failure(let error) = openAI, !openAIKey.isEmpty { errors[.openAI] = error.localizedDescription }
        if case .success(let usage) = anthropic { anthropicUsage = usage }
        if case .failure(let error) = anthropic, !anthropicKey.isEmpty { errors[.anthropic] = error.localizedDescription }

        lastRefresh = .now
        saveCache()
    }

    private func fetchOpenAI(key: String) async -> Result<ProviderUsage, Error> {
        guard !key.isEmpty else { return .success(openAIUsage) }
        do { return .success(try await OpenAIClient().fetchMonth(key: key)) }
        catch { return .failure(error) }
    }

    private func fetchAnthropic(key: String) async -> Result<ProviderUsage, Error> {
        guard !key.isEmpty else { return .success(anthropicUsage) }
        do { return .success(try await AnthropicClient().fetchMonth(key: key)) }
        catch { return .failure(error) }
    }

    private struct Cache: Codable {
        let openAI: ProviderUsage
        let anthropic: ProviderUsage
        let savedAt: Date
    }

    private func saveCache() {
        let cache = Cache(openAI: openAIUsage, anthropic: anthropicUsage, savedAt: .now)
        if let data = try? JSONEncoder().encode(cache) {
            UserDefaults.standard.set(data, forKey: "usageCache")
        }
    }

    private static func loadCache() -> Cache? {
        guard let data = UserDefaults.standard.data(forKey: "usageCache") else { return nil }
        return try? JSONDecoder().decode(Cache.self, from: data)
    }
}
