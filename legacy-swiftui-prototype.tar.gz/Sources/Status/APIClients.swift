import Foundation

enum APIClientError: LocalizedError {
    case invalidURL
    case invalidResponse
    case http(Int, String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            "URL invalide."
        case .invalidResponse:
            "Réponse du fournisseur illisible."
        case .http(let status, let message):
            message.isEmpty ? "Erreur HTTP \(status)." : "Erreur \(status) : \(message)"
        }
    }
}

struct OpenAIClient {
    var session: URLSession = .shared

    func fetchMonth(key: String, now: Date = .now) async throws -> ProviderUsage {
        async let usage = fetchUsage(key: key, now: now)
        async let costs = fetchCosts(key: key, now: now)
        let (usageDays, costDays) = try await (usage, costs)
        return merge(provider: .openAI, usageDays: usageDays, costDays: costDays, now: now)
    }

    private func fetchUsage(key: String, now: Date) async throws -> [DailyUsage] {
        var days: [Date: DailyUsage] = [:]
        var page: String?

        repeat {
            var query = monthQuery(now: now)
            query.append(URLQueryItem(name: "bucket_width", value: "1d"))
            query.append(URLQueryItem(name: "limit", value: "31"))
            if let page { query.append(URLQueryItem(name: "page", value: page)) }

            let response: OpenAIUsageResponse = try await get(
                path: "/v1/organization/usage/completions",
                query: query,
                key: key
            )

            for bucket in response.data {
                let date = Date(timeIntervalSince1970: TimeInterval(bucket.startTime))
                var day = days[date] ?? DailyUsage(date: date, inputTokens: 0, outputTokens: 0, cachedTokens: 0, costUSD: 0, requests: 0)
                for result in bucket.results {
                    day.inputTokens += max(result.inputTokens - result.inputCachedTokens, 0)
                    day.outputTokens += result.outputTokens
                    day.cachedTokens += result.inputCachedTokens
                    day.requests += result.numModelRequests
                }
                days[date] = day
            }
            page = response.nextPage
        } while page != nil

        return days.values.sorted { $0.date < $1.date }
    }

    private func fetchCosts(key: String, now: Date) async throws -> [Date: Double] {
        var days: [Date: Double] = [:]
        var page: String?

        repeat {
            var query = monthQuery(now: now)
            query.append(URLQueryItem(name: "bucket_width", value: "1d"))
            query.append(URLQueryItem(name: "limit", value: "31"))
            if let page { query.append(URLQueryItem(name: "page", value: page)) }

            let response: OpenAICostResponse = try await get(
                path: "/v1/organization/costs",
                query: query,
                key: key
            )
            for bucket in response.data {
                let date = Date(timeIntervalSince1970: TimeInterval(bucket.startTime))
                days[date, default: 0] += bucket.results.reduce(0) { $0 + $1.amount.value }
            }
            page = response.nextPage
        } while page != nil

        return days
    }

    private func get<T: Decodable>(path: String, query: [URLQueryItem], key: String) async throws -> T {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.openai.com"
        components.path = path
        components.queryItems = query
        guard let url = components.url else { throw APIClientError.invalidURL }

        var request = URLRequest(url: url)
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await session.data(for: request)
        try validate(data: data, response: response)
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func monthQuery(now: Date) -> [URLQueryItem] {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0) ?? .current
        let start = calendar.date(from: calendar.dateComponents([.year, .month], from: now)) ?? now
        return [
            URLQueryItem(name: "start_time", value: String(Int(start.timeIntervalSince1970))),
            URLQueryItem(name: "end_time", value: String(Int(now.timeIntervalSince1970)))
        ]
    }
}

struct AnthropicClient {
    var session: URLSession = .shared

    func fetchMonth(key: String, now: Date = .now) async throws -> ProviderUsage {
        async let usage = fetchUsage(key: key, now: now)
        async let costs = fetchCosts(key: key, now: now)
        let (usageDays, costDays) = try await (usage, costs)
        return merge(provider: .anthropic, usageDays: usageDays, costDays: costDays, now: now)
    }

    private func fetchUsage(key: String, now: Date) async throws -> [DailyUsage] {
        var days: [Date: DailyUsage] = [:]
        var page: String?

        repeat {
            var query = monthQuery(now: now)
            query.append(URLQueryItem(name: "bucket_width", value: "1d"))
            query.append(URLQueryItem(name: "limit", value: "31"))
            if let page { query.append(URLQueryItem(name: "page", value: page)) }

            let response: AnthropicUsageResponse = try await get(
                path: "/v1/organizations/usage_report/messages",
                query: query,
                key: key
            )
            for bucket in response.data {
                guard let date = ISO8601DateFormatter().date(from: bucket.startingAt) else { continue }
                var day = days[date] ?? DailyUsage(date: date, inputTokens: 0, outputTokens: 0, cachedTokens: 0, costUSD: 0, requests: 0)
                for result in bucket.results {
                    day.inputTokens += result.uncachedInputTokens
                    day.outputTokens += result.outputTokens
                    day.cachedTokens += result.cacheReadInputTokens + result.cacheCreation.total
                    day.requests += result.requests ?? 0
                }
                days[date] = day
            }
            page = response.hasMore ? response.nextPage : nil
        } while page != nil

        return days.values.sorted { $0.date < $1.date }
    }

    private func fetchCosts(key: String, now: Date) async throws -> [Date: Double] {
        var days: [Date: Double] = [:]
        var page: String?

        repeat {
            var query = monthQuery(now: now)
            query.append(URLQueryItem(name: "bucket_width", value: "1d"))
            query.append(URLQueryItem(name: "limit", value: "31"))
            if let page { query.append(URLQueryItem(name: "page", value: page)) }

            let response: AnthropicCostResponse = try await get(
                path: "/v1/organizations/cost_report",
                query: query,
                key: key
            )
            for bucket in response.data {
                guard let date = ISO8601DateFormatter().date(from: bucket.startingAt) else { continue }
                // Anthropic returns cost amounts in minor currency units (cents for USD).
                days[date, default: 0] += bucket.results.reduce(0) { $0 + ($1.amount.value / 100) }
            }
            page = response.hasMore ? response.nextPage : nil
        } while page != nil

        return days
    }

    private func get<T: Decodable>(path: String, query: [URLQueryItem], key: String) async throws -> T {
        var components = URLComponents()
        components.scheme = "https"
        components.host = "api.anthropic.com"
        components.path = path
        components.queryItems = query
        guard let url = components.url else { throw APIClientError.invalidURL }

        var request = URLRequest(url: url)
        request.setValue(key, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await session.data(for: request)
        try validate(data: data, response: response)
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func monthQuery(now: Date) -> [URLQueryItem] {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(secondsFromGMT: 0) ?? .current
        let start = calendar.date(from: calendar.dateComponents([.year, .month], from: now)) ?? now
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return [
            URLQueryItem(name: "starting_at", value: formatter.string(from: start)),
            URLQueryItem(name: "ending_at", value: formatter.string(from: now))
        ]
    }
}

private func validate(data: Data, response: URLResponse) throws {
    guard let http = response as? HTTPURLResponse else { throw APIClientError.invalidResponse }
    guard 200..<300 ~= http.statusCode else {
        let error = (try? JSONDecoder().decode(ProviderErrorEnvelope.self, from: data).error.message)
            ?? String(data: data, encoding: .utf8)
            ?? ""
        throw APIClientError.http(http.statusCode, error)
    }
}

private func merge(provider: ProviderID, usageDays: [DailyUsage], costDays: [Date: Double], now: Date) -> ProviderUsage {
    let calendar = Calendar(identifier: .gregorian)
    let normalizedCosts = Dictionary(uniqueKeysWithValues: costDays.map { (calendar.startOfDay(for: $0.key), $0.value) })
    var allDays = usageDays.map { day -> DailyUsage in
        var result = day
        result.date = calendar.startOfDay(for: day.date)
        result.costUSD = normalizedCosts[result.date] ?? 0
        return result
    }

    let existingDates = Set(allDays.map(\.date))
    for (date, cost) in normalizedCosts where !existingDates.contains(date) {
        allDays.append(DailyUsage(date: date, inputTokens: 0, outputTokens: 0, cachedTokens: 0, costUSD: cost, requests: 0))
    }
    allDays.sort { $0.date < $1.date }

    return ProviderUsage(
        provider: provider,
        inputTokens: allDays.reduce(0) { $0 + $1.inputTokens },
        outputTokens: allDays.reduce(0) { $0 + $1.outputTokens },
        cachedTokens: allDays.reduce(0) { $0 + $1.cachedTokens },
        costUSD: allDays.reduce(0) { $0 + $1.costUSD },
        requests: allDays.reduce(0) { $0 + $1.requests },
        updatedAt: now,
        daily: allDays,
        isPreview: false
    )
}

private struct ProviderErrorEnvelope: Decodable {
    struct Detail: Decodable { let message: String }
    let error: Detail
}

private struct OpenAIUsageResponse: Decodable {
    let data: [Bucket]
    let nextPage: String?

    enum CodingKeys: String, CodingKey { case data; case nextPage = "next_page" }

    struct Bucket: Decodable {
        let startTime: Int64
        let results: [Result]
        enum CodingKeys: String, CodingKey { case startTime = "start_time"; case results }
    }

    struct Result: Decodable {
        let inputTokens: Int64
        let outputTokens: Int64
        let inputCachedTokens: Int64
        let numModelRequests: Int64

        enum CodingKeys: String, CodingKey {
            case inputTokens = "input_tokens"
            case outputTokens = "output_tokens"
            case inputCachedTokens = "input_cached_tokens"
            case numModelRequests = "num_model_requests"
        }
    }
}

private struct OpenAICostResponse: Decodable {
    let data: [Bucket]
    let nextPage: String?
    enum CodingKeys: String, CodingKey { case data; case nextPage = "next_page" }

    struct Bucket: Decodable {
        let startTime: Int64
        let results: [Result]
        enum CodingKeys: String, CodingKey { case startTime = "start_time"; case results }
    }

    struct Result: Decodable { let amount: Amount }
    struct Amount: Decodable { let value: Double }
}

private struct AnthropicUsageResponse: Decodable {
    let data: [Bucket]
    let hasMore: Bool
    let nextPage: String?
    enum CodingKeys: String, CodingKey { case data; case hasMore = "has_more"; case nextPage = "next_page" }

    struct Bucket: Decodable {
        let startingAt: String
        let results: [Result]
        enum CodingKeys: String, CodingKey { case startingAt = "starting_at"; case results }
    }

    struct Result: Decodable {
        let uncachedInputTokens: Int64
        let cacheCreation: CacheCreation
        let cacheReadInputTokens: Int64
        let outputTokens: Int64
        let requests: Int64?

        enum CodingKeys: String, CodingKey {
            case uncachedInputTokens = "uncached_input_tokens"
            case cacheCreation = "cache_creation"
            case cacheReadInputTokens = "cache_read_input_tokens"
            case outputTokens = "output_tokens"
            case requests
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            uncachedInputTokens = try container.decodeIfPresent(Int64.self, forKey: .uncachedInputTokens) ?? 0
            cacheCreation = try container.decodeIfPresent(CacheCreation.self, forKey: .cacheCreation) ?? .zero
            cacheReadInputTokens = try container.decodeIfPresent(Int64.self, forKey: .cacheReadInputTokens) ?? 0
            outputTokens = try container.decodeIfPresent(Int64.self, forKey: .outputTokens) ?? 0
            requests = try container.decodeIfPresent(Int64.self, forKey: .requests)
        }
    }

    struct CacheCreation: Decodable {
        let ephemeral1hInputTokens: Int64
        let ephemeral5mInputTokens: Int64
        var total: Int64 { ephemeral1hInputTokens + ephemeral5mInputTokens }
        static let zero = CacheCreation(ephemeral1hInputTokens: 0, ephemeral5mInputTokens: 0)

        enum CodingKeys: String, CodingKey {
            case ephemeral1hInputTokens = "ephemeral_1h_input_tokens"
            case ephemeral5mInputTokens = "ephemeral_5m_input_tokens"
        }

        init(ephemeral1hInputTokens: Int64, ephemeral5mInputTokens: Int64) {
            self.ephemeral1hInputTokens = ephemeral1hInputTokens
            self.ephemeral5mInputTokens = ephemeral5mInputTokens
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            ephemeral1hInputTokens = try container.decodeIfPresent(Int64.self, forKey: .ephemeral1hInputTokens) ?? 0
            ephemeral5mInputTokens = try container.decodeIfPresent(Int64.self, forKey: .ephemeral5mInputTokens) ?? 0
        }
    }
}

private struct AnthropicCostResponse: Decodable {
    let data: [Bucket]
    let hasMore: Bool
    let nextPage: String?
    enum CodingKeys: String, CodingKey { case data; case hasMore = "has_more"; case nextPage = "next_page" }

    struct Bucket: Decodable {
        let startingAt: String
        let results: [Result]
        enum CodingKeys: String, CodingKey { case startingAt = "starting_at"; case results }
    }

    struct Result: Decodable {
        let amount: FlexibleDouble
    }

    struct FlexibleDouble: Decodable {
        let value: Double

        init(from decoder: Decoder) throws {
            let container = try decoder.singleValueContainer()
            if let number = try? container.decode(Double.self) {
                value = number
            } else {
                let string = try container.decode(String.self)
                value = Double(string) ?? 0
            }
        }
    }
}
