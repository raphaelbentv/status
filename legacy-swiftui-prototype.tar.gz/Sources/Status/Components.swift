import SwiftUI

struct ProgressRing: View {
    let progress: Double
    let tint: Color
    var lineWidth: CGFloat = 12

    var body: some View {
        ZStack {
            Circle()
                .stroke(tint.opacity(0.12), lineWidth: lineWidth)
            Circle()
                .trim(from: 0, to: min(max(progress, 0), 1))
                .stroke(
                    AngularGradient(colors: [tint.opacity(0.72), tint], center: .center),
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.smooth(duration: 0.55), value: progress)
        }
        .accessibilityLabel("Consommation")
        .accessibilityValue("\(Int(progress * 100)) pour cent")
    }
}

struct ProviderMark: View {
    let provider: ProviderID
    var size: CGFloat = 36

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.28, style: .continuous)
                .fill(provider.tint.opacity(0.13))
            Image(systemName: provider.symbol)
                .font(.system(size: size * 0.42, weight: .semibold))
                .foregroundStyle(provider.tint)
        }
        .frame(width: size, height: size)
    }
}

struct MetricLabel: View {
    let title: String
    let value: String
    var detail: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundStyle(.secondary)
            Text(value)
                .font(.system(size: 20, weight: .semibold, design: .rounded))
                .contentTransition(.numericText())
            if let detail {
                Text(detail)
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
        }
    }
}

struct StatusDot: View {
    let active: Bool

    var body: some View {
        Circle()
            .fill(active ? Color.green : Color.secondary.opacity(0.35))
            .frame(width: 7, height: 7)
            .shadow(color: active ? .green.opacity(0.45) : .clear, radius: 4)
    }
}

struct PillButtonStyle: ButtonStyle {
    var prominent = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.callout.weight(.medium))
            .padding(.horizontal, 13)
            .padding(.vertical, 8)
            .background(prominent ? Color.accentColor.opacity(configuration.isPressed ? 0.72 : 1) : Color.primary.opacity(configuration.isPressed ? 0.12 : 0.07))
            .foregroundStyle(prominent ? Color.white : Color.primary)
            .clipShape(Capsule())
            .animation(.easeOut(duration: 0.12), value: configuration.isPressed)
    }
}
