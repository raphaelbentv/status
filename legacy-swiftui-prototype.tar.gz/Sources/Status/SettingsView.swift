import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: AppStore

    @State private var openAIKey = ""
    @State private var anthropicKey = ""
    @State private var saveMessage: String?

    @AppStorage("openAITokenBudget") private var openAITokenBudget = 10_000_000
    @AppStorage("anthropicTokenBudget") private var anthropicTokenBudget = 10_000_000
    @AppStorage("openAICostBudget") private var openAICostBudget = 50.0
    @AppStorage("anthropicCostBudget") private var anthropicCostBudget = 50.0
    @AppStorage("refreshIntervalMinutes") private var refreshIntervalMinutes = 30

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 5) {
                Text("Réglages")
                    .font(.system(size: 25, weight: .bold, design: .rounded))
                Text("Les clés sont stockées dans le Trousseau de ce Mac.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
            .padding(24)

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 26) {
                    providerSection(
                        provider: .openAI,
                        key: $openAIKey,
                        tokenBudget: $openAITokenBudget,
                        costBudget: $openAICostBudget,
                        keyHint: "Clé administrateur OpenAI"
                    )

                    Divider()

                    providerSection(
                        provider: .anthropic,
                        key: $anthropicKey,
                        tokenBudget: $anthropicTokenBudget,
                        costBudget: $anthropicCostBudget,
                        keyHint: "Clé administrateur Anthropic"
                    )

                    Divider()

                    HStack {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Actualisation automatique")
                                .font(.callout.weight(.medium))
                            Text("Fréquence de synchronisation en arrière-plan.")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Picker("", selection: $refreshIntervalMinutes) {
                            Text("15 min").tag(15)
                            Text("30 min").tag(30)
                            Text("1 heure").tag(60)
                        }
                        .labelsHidden()
                        .frame(width: 110)
                    }
                }
                .padding(24)
            }

            Divider()

            HStack {
                if let saveMessage {
                    Text(saveMessage)
                        .font(.caption)
                        .foregroundStyle(saveMessage.contains("Erreur") ? .red : .secondary)
                }
                Spacer()
                Button("Enregistrer") {
                    save()
                }
                .buttonStyle(PillButtonStyle(prominent: true))
            }
            .padding(18)
        }
        .frame(width: 560, height: 600)
        .onAppear {
            openAIKey = KeychainStore.read(AppStore.openAIAccount) ?? ""
            anthropicKey = KeychainStore.read(AppStore.anthropicAccount) ?? ""
        }
    }

    private func providerSection(
        provider: ProviderID,
        key: Binding<String>,
        tokenBudget: Binding<Int>,
        costBudget: Binding<Double>,
        keyHint: String
    ) -> some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 11) {
                ProviderMark(provider: provider, size: 38)
                VStack(alignment: .leading, spacing: 2) {
                    Text(provider.name).font(.headline)
                    Text("API d’organisation")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                StatusDot(active: !key.wrappedValue.isEmpty)
            }

            LabeledContent("Clé API") {
                SecureField(keyHint, text: key)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 310)
            }

            LabeledContent("Budget tokens mensuel") {
                TextField("10 000 000", value: tokenBudget, format: .number)
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 150)
                    .multilineTextAlignment(.trailing)
            }

            LabeledContent("Budget coût mensuel") {
                TextField("50", value: costBudget, format: .currency(code: "USD"))
                    .textFieldStyle(.roundedBorder)
                    .frame(width: 150)
                    .multilineTextAlignment(.trailing)
            }
        }
    }

    private func save() {
        do {
            try KeychainStore.save(openAIKey.trimmingCharacters(in: .whitespacesAndNewlines), account: AppStore.openAIAccount)
            try KeychainStore.save(anthropicKey.trimmingCharacters(in: .whitespacesAndNewlines), account: AppStore.anthropicAccount)
            saveMessage = "Réglages enregistrés."
            Task { await store.refresh() }
        } catch {
            saveMessage = "Erreur : \(error.localizedDescription)"
        }
    }
}
