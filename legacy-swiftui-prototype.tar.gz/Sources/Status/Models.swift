import Foundation
import SwiftUI

enum ProviderID: String, CaseIterable, Codable, Identifiable, Hashable {
    case openAI
    case anthropic

    var id: String { rawValue }

    var name: String {
        switch self {
        case .openAI: "OpenAI"
        case .anthropic: "Claude"
        }
    }

    var shortName: String {
        switch self {
        case .openAI: "AI"
        case .anthropic: "C"
        }
    }

    var symbol: String {
        switch self {
        case .openAI: "circle.hexagongrid.fill"
        case .anthropic: "sparkles"
        }
    }

    var tint: Color {
        switch self {
        case .openAI: Color(red: 0.20, green: 0.38, blue: 0.95)
        case .anthropic: Color(red: 0.72, green: 0.35, blue: 0.94)
        }
    }
}

struct DailyUsage: Codable, Identifiable, Hashable {
    var date: Date
    var inputTokens: Int64
    var outputTokens: Int64
    var cachedTokens: Int64
    var costUSD: Double
    var requests: Int64

    var id: Date { date }
    var totalTokens: Int64 { inputTokens + outputTokens + cachedTokens }
}

struct ProviderUsage: Codable, Identifiable, Hashable {
    var provider: ProviderID
    var inputTokens: Int64
    var outputTokens: Int64
    var cachedTokens: Int64
    var costUSD: Double
    var requests: Int64
    var updatedAt: Date
    var daily: [DailyUsage]
    var isPreview: Bool

    var id: ProviderID { provider }
    var totalTokens: Int64 { inputTokens + outputTokens + cachedTokens }

    static func empty(_ provider: ProviderID) -> ProviderUsage {
        ProviderUsage(
            provider: provider,
            inputTokens: 0,
            outputTokens: 0,
            cachedTokens: 0,
            costUSD: 0,
            requests: 0,
            updatedAt: .now,
            daily: [],
            isPreview: false
        )
    }

    static func preview(_ provider: ProviderID, now: Date = .now) -> ProviderUsage {
        let calendar = Calendar.current
        let seed: [(Int64, Int64, Int64, Double)] = provider == .openAI
            ? [(95, 28, 41, 1.42), (132, 36, 52, 1.90), (88, 42, 67, 1.76), (156, 48, 75, 2.31), (142, 51, 89, 2.48), (201, 73, 110, 3.22), (178, 61, 94, 2.74), (226, 82, 128, 3.61), (191, 69, 101, 2.98), (244, 91, 136, 3.89), (218, 79, 122, 3.44), (267, 104, 149, 4.21)]
            : [(72, 24, 32, 1.06), (84, 31, 38, 1.24), (67, 29, 45, 1.18), (108, 37, 56, 1.62), (96, 40, 62, 1.58), (126, 46, 71, 1.93), (117, 42, 69, 1.81), (143, 51, 80, 2.16), (135, 49, 76, 2.05), (158, 57, 88, 2.38), (149, 53, 84, 2.24), (176, 65, 97, 2.67)]

        let daily = seed.enumerated().map { index, values in
            let date = calendar.date(byAdding: .day, value: index - seed.count + 1, to: now) ?? now
            return DailyUsage(
                date: calendar.startOfDay(for: date),
                inputTokens: values.0 * 1_000,
                outputTokens: values.1 * 1_000,
                cachedTokens: values.2 * 1_000,
                costUSD: values.3,
                requests: values.0 / 2
            )
        }

        return ProviderUsage(
            provider: provider,
            inputTokens: daily.reduce(0) { $0 + $1.inputTokens },
            outputTokens: daily.reduce(0) { $0 + $1.outputTokens },
            cachedTokens: daily.reduce(0) { $0 + $1.cachedTokens },
            costUSD: daily.reduce(0) { $0 + $1.costUSD },
            requests: daily.reduce(0) { $0 + $1.requests },
            updatedAt: now,
            daily: daily,
            isPreview: true
        )
    }
}

extension Int64 {
    var compactTokens: String {
        let value = Double(self)
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "fr_FR")
        formatter.maximumFractionDigits = 1
        formatter.minimumFractionDigits = 0

        if abs(value) >= 1_000_000_000 {
            return "\(formatter.string(from: NSNumber(value: value / 1_000_000_000)) ?? "0") Md"
        }
        if abs(value) >= 1_000_000 {
            return "\(formatter.string(from: NSNumber(value: value / 1_000_000)) ?? "0") M"
        }
        if abs(value) >= 1_000 {
            return "\(formatter.string(from: NSNumber(value: value / 1_000)) ?? "0") k"
        }
        return formatter.string(from: NSNumber(value: value)) ?? "0"
    }
}

extension Double {
    var usd: String {
        formatted(.currency(code: "USD").locale(Locale(identifier: "fr_FR")))
    }
}

extension Date {
    var shortFrenchDate: String {
        formatted(.dateTime.day().month(.abbreviated).locale(Locale(identifier: "fr_FR")))
    }
}
