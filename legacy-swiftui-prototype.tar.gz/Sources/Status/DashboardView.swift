import Charts
import SwiftUI

enum DashboardSection: Hashable {
    case overview
    case provider(ProviderID)
}

struct DashboardView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selection: DashboardSection = .overview

    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Divider().opacity(0.55)
            mainContent
        }
        .frame(minWidth: 820, minHeight: 560)
        .background(Color(nsColor: .windowBackgroundColor))
        .task { await store.refresh() }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 10, style: .continuous)
                        .fill(Color.accentColor.gradient)
                    Image(systemName: "gauge.with.dots.needle.67percent")
                        .foregroundStyle(.white)
                        .font(.system(size: 17, weight: .semibold))
                }
                .frame(width: 36, height: 36)

                VStack(alignment: .leading, spacing: 1) {
                    Text("Status")
                        .font(.headline)
                    Text("Usage API")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.bottom, 22)

            sidebarButton("Vue d’ensemble", symbol: "chart.xyaxis.line", section: .overview)

            Text("FOURNISSEURS")
                .font(.system(size: 10, weight: .semibold))
                .foregroundStyle(.tertiary)
                .padding(.top, 19)
                .padding(.bottom, 4)

            ForEach(ProviderID.allCases) { provider in
                sidebarButton(provider.name, symbol: provider.symbol, section: .provider(provider))
            }

            Spacer()

            if store.isPreview {
                HStack(alignment: .top, spacing: 8) {
                    Image(systemName: "eye")
                        .foregroundStyle(Color.accentColor)
                    Text("Mode aperçu\nAjoutez vos clés dans Réglages.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.bottom, 10)
            }

            HStack(spacing: 7) {
                StatusDot(active: !store.isPreview && store.errors.isEmpty)
                Text(store.isPreview ? "Non connecté" : store.errors.isEmpty ? "Données à jour" : "Attention requise")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(20)
        .frame(width: 210)
        .background(.ultraThinMaterial)
    }

    private func sidebarButton(_ title: String, symbol: String, section: DashboardSection) -> some View {
        Button {
            withAnimation(.snappy(duration: 0.25)) { selection = section }
        } label: {
            HStack(spacing: 10) {
                Image(systemName: symbol)
                    .frame(width: 17)
                Text(title)
                Spacer()
            }
            .font(.callout.weight(selection == section ? .semibold : .regular))
            .foregroundStyle(selection == section ? Color.primary : Color.secondary)
            .padding(.horizontal, 10)
            .padding(.vertical, 8)
            .background(selection == section ? Color.primary.opacity(0.07) : .clear)
            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var mainContent: some View {
        Group {
            switch selection {
            case .overview:
                OverviewView()
                    .transition(.opacity.combined(with: .move(edge: .leading)))
            case .provider(let provider):
                ProviderDetailView(provider: provider)
                    .transition(.opacity.combined(with: .move(edge: .trailing)))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct OverviewView: View {
    @EnvironmentObject private var store: AppStore

    private var combinedDaily: [DailyUsage] {
        let calendar = Calendar.current
        var values: [Date: DailyUsage] = [:]
        for usage in store.providers {
            for day in usage.daily {
                let date = calendar.startOfDay(for: day.date)
                var current = values[date] ?? DailyUsage(date: date, inputTokens: 0, outputTokens: 0, cachedTokens: 0, costUSD: 0, requests: 0)
                current.inputTokens += day.inputTokens
                current.outputTokens += day.outputTokens
                current.cachedTokens += day.cachedTokens
                current.costUSD += day.costUSD
                current.requests += day.requests
                values[date] = current
            }
        }
        return values.values.sorted { $0.date < $1.date }
    }

    private var totalBudget: Int64 {
        ProviderID.allCases.reduce(0) { $0 + store.tokenBudget(for: $1) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                header
                summary
                providerList
                usageChart
            }
            .padding(30)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Ce mois")
                    .font(.system(size: 29, weight: .bold, design: .rounded))
                Text(Date.now.formatted(.dateTime.month(.wide).year().locale(Locale(identifier: "fr_FR"))))
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button {
                Task { await store.refresh() }
            } label: {
                Label("Actualiser", systemImage: "arrow.clockwise")
                    .opacity(store.isRefreshing ? 0.65 : 1)
            }
            .buttonStyle(PillButtonStyle())
            .disabled(store.isRefreshing)
        }
    }

    private var summary: some View {
        HStack(spacing: 34) {
            ZStack {
                ProgressRing(
                    progress: totalBudget > 0 ? Double(store.totalTokens) / Double(totalBudget) : 0,
                    tint: .accentColor,
                    lineWidth: 14
                )
                VStack(spacing: 1) {
                    Text(store.totalTokens.compactTokens)
                        .font(.system(size: 27, weight: .bold, design: .rounded))
                    Text("tokens")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: 142, height: 142)

            VStack(alignment: .leading, spacing: 18) {
                Text("CONSOMMATION TOTALE")
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundStyle(.tertiary)
                HStack(spacing: 44) {
                    MetricLabel(title: "Entrée", value: store.providers.reduce(0) { $0 + $1.inputTokens }.compactTokens)
                    MetricLabel(title: "Sortie", value: store.providers.reduce(0) { $0 + $1.outputTokens }.compactTokens)
                    MetricLabel(title: "Cache", value: store.providers.reduce(0) { $0 + $1.cachedTokens }.compactTokens)
                }
                Divider()
                HStack(spacing: 44) {
                    MetricLabel(title: "Coût estimé", value: store.totalCost.usd)
                    MetricLabel(title: "Requêtes", value: store.providers.reduce(0) { $0 + $1.requests }.formatted())
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(.vertical, 4)
    }

    private var providerList: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("Par fournisseur")
                .font(.headline)
                .padding(.bottom, 12)

            ForEach(Array(store.providers.enumerated()), id: \.element.id) { index, usage in
                if index > 0 { Divider().padding(.leading, 52) }
                ProviderUsageRow(usage: usage, budget: store.tokenBudget(for: usage.provider), error: store.errors[usage.provider])
            }
        }
    }

    private var usageChart: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Rythme quotidien")
                    .font(.headline)
                Spacer()
                Text("Tokens par jour")
                    .font(.caption)
                    .foregroundStyle(.tertiary)
            }

            Chart(combinedDaily) { day in
                BarMark(
                    x: .value("Jour", day.date, unit: .day),
                    y: .value("Tokens", day.totalTokens)
                )
                .foregroundStyle(Color.accentColor.gradient)
                .cornerRadius(3)
            }
            .chartXAxis {
                AxisMarks(values: .stride(by: .day, count: max(combinedDaily.count / 6, 1))) { _ in
                    AxisValueLabel(format: .dateTime.day().month(.abbreviated))
                        .foregroundStyle(Color.secondary)
                }
            }
            .chartYAxis {
                AxisMarks(position: .leading) { value in
                    AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                    AxisValueLabel {
                        if let number = value.as(Int64.self) { Text(number.compactTokens) }
                    }
                }
            }
            .frame(height: 145)
        }
    }
}

struct ProviderUsageRow: View {
    let usage: ProviderUsage
    let budget: Int64
    let error: String?

    private var progress: Double {
        budget > 0 ? Double(usage.totalTokens) / Double(budget) : 0
    }

    var body: some View {
        HStack(spacing: 14) {
            ProviderMark(provider: usage.provider, size: 38)
            VStack(alignment: .leading, spacing: 5) {
                HStack(spacing: 7) {
                    Text(usage.provider.name).font(.callout.weight(.semibold))
                    if usage.isPreview {
                        Text("APERÇU")
                            .font(.system(size: 8, weight: .bold))
                            .foregroundStyle(usage.provider.tint)
                    }
                }
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.primary.opacity(0.07))
                        Capsule()
                            .fill(usage.provider.tint)
                            .frame(width: geometry.size.width * min(max(progress, 0), 1))
                    }
                }
                .frame(height: 5)
                if let error {
                    Text(error)
                        .font(.caption2)
                        .foregroundStyle(.red)
                        .lineLimit(1)
                }
            }
            .frame(maxWidth: .infinity)

            VStack(alignment: .trailing, spacing: 2) {
                Text(usage.totalTokens.compactTokens)
                    .font(.system(.body, design: .rounded, weight: .semibold))
                Text("sur \(budget.compactTokens)")
                    .font(.caption2)
                    .foregroundStyle(.tertiary)
            }
            .frame(width: 92, alignment: .trailing)

            Text(usage.costUSD.usd)
                .font(.callout.monospacedDigit())
                .frame(width: 74, alignment: .trailing)
        }
        .padding(.vertical, 13)
    }
}

struct ProviderDetailView: View {
    @EnvironmentObject private var store: AppStore
    let provider: ProviderID

    private var usage: ProviderUsage { store.usage(for: provider) }
    private var budget: Int64 { store.tokenBudget(for: provider) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                HStack {
                    ProviderMark(provider: provider, size: 48)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(provider.name)
                            .font(.system(size: 29, weight: .bold, design: .rounded))
                        Text("Consommation du mois en cours")
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    StatusDot(active: store.isConfigured(provider) && store.errors[provider] == nil)
                }

                HStack(spacing: 42) {
                    ZStack {
                        ProgressRing(progress: budget > 0 ? Double(usage.totalTokens) / Double(budget) : 0, tint: provider.tint, lineWidth: 13)
                        VStack(spacing: 2) {
                            Text(usage.totalTokens.compactTokens)
                                .font(.system(size: 25, weight: .bold, design: .rounded))
                            Text("/ \(budget.compactTokens)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(width: 132, height: 132)

                    VStack(alignment: .leading, spacing: 22) {
                        HStack(spacing: 52) {
                            MetricLabel(title: "Entrée", value: usage.inputTokens.compactTokens)
                            MetricLabel(title: "Sortie", value: usage.outputTokens.compactTokens)
                            MetricLabel(title: "Cache", value: usage.cachedTokens.compactTokens)
                        }
                        HStack(spacing: 52) {
                            MetricLabel(title: "Coût", value: usage.costUSD.usd)
                            MetricLabel(title: "Requêtes", value: usage.requests.formatted())
                            MetricLabel(title: "Budget coût", value: store.costBudget(for: provider).usd)
                        }
                    }
                }

                Divider()

                VStack(alignment: .leading, spacing: 12) {
                    Text("Historique quotidien").font(.headline)
                    Chart(usage.daily) { day in
                        BarMark(x: .value("Jour", day.date, unit: .day), y: .value("Tokens", day.totalTokens))
                            .foregroundStyle(provider.tint.gradient)
                            .cornerRadius(4)
                    }
                    .chartXAxis {
                        AxisMarks(values: .automatic(desiredCount: 7)) { _ in
                            AxisValueLabel(format: .dateTime.day().month(.abbreviated))
                        }
                    }
                    .chartYAxis {
                        AxisMarks(position: .leading) { value in
                            AxisGridLine().foregroundStyle(Color.primary.opacity(0.06))
                            AxisValueLabel {
                                if let number = value.as(Int64.self) { Text(number.compactTokens) }
                            }
                        }
                    }
                    .frame(height: 210)
                }

                if let error = store.errors[provider] {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(.callout)
                        .foregroundStyle(.red)
                        .padding(12)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(.red.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                }
            }
            .padding(30)
        }
    }
}
