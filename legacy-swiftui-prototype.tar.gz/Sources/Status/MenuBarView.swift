import AppKit
import SwiftUI

struct MenuBarView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Status")
                            .font(.headline)
                        Text("Ce mois")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if store.isPreview {
                        Text("APERÇU")
                            .font(.system(size: 9, weight: .bold))
                            .foregroundStyle(Color.accentColor)
                    }
                }

                HStack(spacing: 18) {
                    ZStack {
                        ProgressRing(progress: totalProgress, tint: .accentColor, lineWidth: 9)
                        Text(store.totalTokens.compactTokens)
                            .font(.system(size: 19, weight: .bold, design: .rounded))
                    }
                    .frame(width: 94, height: 94)

                    VStack(alignment: .leading, spacing: 11) {
                        MetricLabel(title: "Coût total", value: store.totalCost.usd)
                        Text(store.lastRefresh.map { "Mis à jour à \($0.formatted(.dateTime.hour().minute()))" } ?? "Pas encore synchronisé")
                            .font(.caption2)
                            .foregroundStyle(.tertiary)
                    }
                    Spacer()
                }
            }
            .padding(18)

            Divider()

            VStack(spacing: 0) {
                ForEach(store.providers) { usage in
                    HStack(spacing: 11) {
                        ProviderMark(provider: usage.provider, size: 32)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(usage.provider.name).font(.callout.weight(.medium))
                            Text(usage.costUSD.usd).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text(usage.totalTokens.compactTokens)
                            .font(.system(.callout, design: .rounded, weight: .semibold))
                    }
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                }
            }

            Divider()

            HStack {
                Button {
                    NSApp.activate(ignoringOtherApps: true)
                    openWindow(id: "dashboard")
                } label: {
                    Label("Ouvrir", systemImage: "macwindow")
                }
                .buttonStyle(.plain)

                Spacer()

                Button {
                    Task { await store.refresh() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                        .opacity(store.isRefreshing ? 0.65 : 1)
                }
                .buttonStyle(.plain)
                .disabled(store.isRefreshing)

                SettingsLink {
                    Image(systemName: "gearshape")
                }
                .buttonStyle(.plain)

                Button {
                    NSApplication.shared.terminate(nil)
                } label: {
                    Image(systemName: "power")
                }
                .buttonStyle(.plain)
            }
            .foregroundStyle(.secondary)
            .padding(.horizontal, 18)
            .padding(.vertical, 13)
        }
        .frame(width: 330)
    }

    private var totalProgress: Double {
        let budget = ProviderID.allCases.reduce(Int64(0)) { $0 + store.tokenBudget(for: $1) }
        return budget > 0 ? Double(store.totalTokens) / Double(budget) : 0
    }
}
